window.appConfig = {
    backendUrl: "http://192.168.0.5:9030"
}